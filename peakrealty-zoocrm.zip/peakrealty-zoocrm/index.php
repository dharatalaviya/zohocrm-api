<?php 

// All is well